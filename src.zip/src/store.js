import { createStore, applyMiddleware, compose } from 'redux';
import rootReducer from './reducers';
import thunk from "redux-thunk";

const composeEnhancers =
  typeof window === 'object' &&
  window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ?
    window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({
      // Specify extension’s options like name, actionsBlacklist, actionsCreators, serialize...
    }) : compose;

const storeConfig = preloadState => (
  createStore(
    rootReducer,
    preloadState,
    composeEnhancers(
      applyMiddleware(thunk)
    )
  )
);

const store = storeConfig({});

export default store;