import {ADD_TASK, CHANGE_FILTER, COMPLETE_TASK, INIT_TASKS, REMOVE_TASK} from '../constans'
import axios from '../apiServices/apiServicesTasks'

export const changeFilter = (mode) => ({
  type: CHANGE_FILTER,
  mode
})

export const addTask = (taskText, isCompleted) => async (dispatch) => {
  let response = await axios.post('/', {
    taskText,
    isCompleted
  });
  response = await response.data;

  dispatch({
    type: ADD_TASK,
    ...response
  })
};

export const removeTask = id => async (dispatch) => {
  let response = await axios.delete(`/${id}`);
  response = await response.data.id;

  dispatch({
    type: REMOVE_TASK,
    id: response
  })
};

export const completeTask = (id, isCompleted) => async (dispatch) => {
  let response = await axios.put(`/${id}`, {
    isCompleted: !isCompleted
  });
  response = await response.data;

  dispatch({
    type: COMPLETE_TASK,
    id: response.id,
    isCompleted: response.isCompleted
  })
};

export const initTask = () => {
  return async function (dispatch) {
    let response = await axios.get('/');
    response = await response.data;

    dispatch({
        type: INIT_TASKS,
        tasks: response
    });
  }
};