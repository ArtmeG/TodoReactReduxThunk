import React, { Component } from 'react';
import { connect } from "react-redux";
import PropTypes from "prop-types";

import { removeTask, completeTask } from '../../actions/actionCreator'

import TodoItem from "../todo-item/TodoItem";
import {TAB_COMPLETE, TAB_UNCOMPLETE} from "../../constans";

class TodoList extends Component {

  deleteTodoItem = (id) => {
    this.props.removeTask(id);
  }

  completeTodoItem = (id, isCompleted) => {
    this.props.completeTask(id, isCompleted);
  }

  renderList = () => {
    const { tasks, mode } = this.props;
    switch (mode) {
      case TAB_COMPLETE:
        return tasks.filter((task) => task.isCompleted);
      case TAB_UNCOMPLETE:
        return tasks.filter((task) => !task.isCompleted);
      default:
        return tasks || [];
    }
  }

  render() {
    const tasks = this.renderList();
    return (
      <ul className='ui raised segment'>
        {tasks.map((task) => <TodoItem
          key={task.id}
          deleteTodoItem={this.deleteTodoItem}
          completeTodoItem={this.completeTodoItem}
          task={task}
        />)}
      </ul>
    )
  }
}

TodoList.propTypes = {
  tasks: PropTypes.array.isRequired,
  mode: PropTypes.string.isRequired,
  removeTask: PropTypes.func,
  completeTask: PropTypes.func
}

TodoList.defaultProps = {
  tasks: [],
  mode: 'all',
  removeTask: () => {},
  completeTask: () => {}
}

export default connect(({tasks, mode}) => ({
  tasks,
  mode
}),
  {
    removeTask,
    completeTask
  })(TodoList);

