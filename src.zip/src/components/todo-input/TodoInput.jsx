import React, {Component} from 'react';
import * as PropTypes from "prop-types";

class TodoInput extends Component {
  render() {
    const {
      value,
      onChangeInputHandler,
      onKeyPressInputHandler
    } = this.props;

    return (
      <div>
        <input
          type="text"
          value={value}
          onChange={onChangeInputHandler}
          onKeyPress={onKeyPressInputHandler}
          placeholder='Enter a text task'
        />
        <i className='fa fa-plus' />
      </div>
    )
  }
}

TodoInput.propTypes = {
  value: PropTypes.string,
  onChangeInputHandler: PropTypes.func,
  onKeyPressInputHandler: PropTypes.func
}

TodoInput.defaultPro = {
  value: '',
  onChangeInputHandler: () => {},
  onKeyPressInputHandler: () => {}
}

export default TodoInput;