import React, {PureComponent} from 'react';
import PropTypes from 'prop-types';

class Title extends PureComponent {
  render() {
    return (
      <h2>{this.props.title}</h2>
    )
  }
}

Title.propTypes = {
  title: PropTypes.string
}

Title.defaultProps = {
  title: 'Something went wrong. Please check props.'
}

export default Title;