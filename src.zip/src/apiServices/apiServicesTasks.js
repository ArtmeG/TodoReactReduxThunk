import axios from 'axios';

export default axios.create({
  baseURL: 'https://5ffad9cb87478d0017d9a901.mockapi.io/todo',
  headers: {
    'Content-Type': 'application/json'
  }
})